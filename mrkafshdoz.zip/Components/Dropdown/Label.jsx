

const Label = ({ name }) => {
    return (
        <>
            <span>{name}</span>
        </>
    );
};

export default Label;