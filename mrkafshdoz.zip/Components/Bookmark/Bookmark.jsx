import style from './Bookmark.module.css'

const Bookmark = () => {
    return (
        <>
            
        </>
    );
};

export default Bookmark;